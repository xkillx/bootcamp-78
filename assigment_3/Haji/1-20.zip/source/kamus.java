package com.xsis;

public class kamus{

	/*private int a;
	public void setJumlah(int a, int b){
		this.a=a+b;
	}*/
	
	public Integer getJumlah(){
		return 4000;
	}
}