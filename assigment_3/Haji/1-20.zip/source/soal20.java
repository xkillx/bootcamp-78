package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal20{
	public static void main(String args[]){	
		int n,k=0;
		
		System.out.print("Masukkan nilai n: ");
		Scanner in = new Scanner(System.in);
		n = in.nextInt();		
		
		for (int i=-n+1; i<=n-1;i++){
			for (int j=-n+1;j<=n-1;j++){
				if(Math.abs(j)<=k) System.out.print("*");
				else System.out.print(" ");
			}
			System.out.println();
			if(i<0) k++;
			else k--;
		}
	}
}