package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal12{
	public static void main(String args[]){	
		int n;
		
		System.out.print("Masukkan nilai n: ");
		Scanner in = new Scanner(System.in);
		n = in.nextInt();		
		
		for (int i=0; i<n;i++){
			for (int j=-n;j<=n;j++){
				if (Math.abs(j)>i)
					System.out.print("+");
				else if(Math.abs(j)==i)
					System.out.print("@");
				else System.out.print("-");
			}
			System.out.println();
		}
	}
}