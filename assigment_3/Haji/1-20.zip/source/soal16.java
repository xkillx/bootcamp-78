package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal16{
	public static void main(String args[]){	
		int n;
		
		System.out.print("Masukkan nilai n: ");
		Scanner in = new Scanner(System.in);
		n = in.nextInt();		
		
		for (int i=0; i<n;i++){
			for (int j=-n+1;j<=n-1;j++){
				if (Math.abs(j)<=i)
					System.out.print("*");
				else System.out.print(" ");
			}
			System.out.println();
		}
	}
}