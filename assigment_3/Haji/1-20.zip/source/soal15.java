package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal15{
	public static void main(String args[]){	
		int n,m,o=0;
		
		Scanner in = new Scanner(System.in);

		System.out.print("Masukkan nilai n: ");
		n = in.nextInt();		
		
		System.out.print("Masukkan nilai m: ");
		m = in.nextInt();		
		
		for (int i=1; i<=n; i++){
			System.out.print(i);
			o++;
			if (o==m){
				System.out.println();
				o=0;
			}
		}
	}
}