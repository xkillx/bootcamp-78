package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal10{
	public static void main(String args[]){	
		int n;
		int a=1;
		
		System.out.print("Masukkan nilai n: ");
		Scanner in = new Scanner(System.in);
		n = in.nextInt();		
		
		for (int i=1;i<=n;i++){
			a=i;
			for (int j=n;j>0;j--){
				if (j<=i){
					System.out.print(a);
					a--;
				}
				else System.out.print(" ");
			}
			System.out.println();
		}
	}
}