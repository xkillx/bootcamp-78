package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal6{
	public static void main(String args[]){	
		int n;
		int a;
		
		System.out.print("Masukkan nilai n: ");
		Scanner in = new Scanner(System.in);
		n = in.nextInt();		
		
		for (int i=1;i<=n;i++){
			a=i;
			for (int j=0;j<=n*2-i*2;j++){
				System.out.print(a);
				a=a+1;
			}
			System.out.print("\n");
			
			for (int k=0;k<i;k++){
				System.out.print(" ");
			}
		}
	}
}