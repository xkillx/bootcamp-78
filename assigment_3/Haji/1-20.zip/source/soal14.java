package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal14{
	public static void main(String args[]){	
		int n;
		
		System.out.print("Masukkan nilai n: ");
		Scanner in = new Scanner(System.in);
		n = in.nextInt();		
		
		for (int i=-n; i<=n; i++){
			if (i!=0&&i!=1){
				int k=1;
				for (int j=0; j<Math.abs(i); j++){
					System.out.print(k);
					k+=2;
				}
				System.out.println();
			}
		}
	}
}