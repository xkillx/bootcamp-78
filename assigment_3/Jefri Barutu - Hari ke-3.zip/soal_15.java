package com.xsis.bootcamp;

import java.util.Scanner;

public class soal_15 {
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.print("Input n = ");
		int n = scan.nextInt();
		System.out.print("Input m = ");
		int m = scan.nextInt();
	
		for(int i=1; i<=n; i++){
		//int a=1;
			System.out.print(i);
		if(i%m==0){
			System.out.println("");
			}
			
		
	}

}
}