package com.xsis.soal;

public class soal19 {
	
	public static void main (String args[])
	{
		int n = 9;
		
		for (int i=1;i<=n;i++)
		{
			
			for (int j=n;j>i;j--)
			{
				System.out.print(" ");
			}
			
			
			for (int k=1;k<=2*i-1;k++)
			{
				if ( k==1 || i==n || k==2*i-1) // i buat baris ,  
				{
					System.out.print(i);
				}
				else
				{
					System.out.print(" ");
				}
				
			}
			
			
			for (int l=n;l>i;l--)
			{
				System.out.print(" ");
			}
			
		System.out.println();
		}
	}
}
