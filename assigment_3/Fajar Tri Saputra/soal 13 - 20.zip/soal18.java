package com.xsis.soal;

public class soal18 {
	
	public static void main (String args []){
		
		int n = 5;
		int x = 0;

		for (int a=1;a<=n;a++)
		{
			for (int b=1;b<=a;b++)
			{
				if (b==1 || b==a)
				{
					System.out.print("1");
				}
				else
				{
					System.out.print(x);
				}
			}
			x+=2;
			System.out.println();
		}	
	}
}
