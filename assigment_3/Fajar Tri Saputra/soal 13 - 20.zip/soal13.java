package com.xsis.soal;

public class soal13 {
	
	public static void main (String args[]) {
		
		int n = 5;
		int x;
		
		for ( int i=1; i<=n;i++ )
		{
			
			x=i; // setelah print 1 nilai a mengikuti i jadi = 2
			
			for ( int j=1;j<=i;j++ ) // setelah kondisi j<=i terpenuhi, nilai j kembali ke 1
			{ 
				System.out.print(x);
				x++;
			}
			x=x-2; //loop pertama nilai a jadi 2 - 2, loop kedua 4 - 2
			
			for ( int k=i;k>1;k-- )
			{
				System.out.print(x);
				x--;
			}
			System.out.println();
		}
		
	}
}
