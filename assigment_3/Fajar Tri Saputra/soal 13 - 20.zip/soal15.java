package com.xsis.soal;
import java.util.Scanner;
public class soal15 {
	
public static void main (String args[]) {
	
	//int n = 9; // inputan batas angka
	//int x = 4; // inputan batas kolom
	
	System.out.println("BATAS BARIS = 3");
	System.out.println();
	
	Scanner input = new Scanner(System.in);
	System.out.print("Masukkan batas angka: ");
	int n = input.nextInt();

	System.out.print("Masukkan batas kolom: ");
	int x = input.nextInt();
	
	int a = 1;
	
	System.out.println();
		
		for ( int i=1; i<=3; i++)
		{
			for ( int j=1; j<=x; j++)
			{
				if (a<=n)
				{
				System.out.print(a+" ");
				a++;
				}
			}
			System.out.println();
		}
	}
}
