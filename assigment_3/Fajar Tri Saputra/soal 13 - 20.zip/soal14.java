package com.xsis.soal;

public class soal14 {

public static void main (String args[]) {
		
		int n = 9;
		int x;
		
		for ( int i=n; i>=1;i-- )
		{
			x = 1;
			for ( int j=1; j<=i;j++)
			{
				System.out.print(x+" ");
				x+=2;
			}
			System.out.println();
		}
		
		for ( int i=1; i<=n;i++ )
		{
			x = 1;
			for ( int k=1; k<=i+1;k++)
			{
				System.out.print(x+" ");
				x+=2;
			}
			System.out.println();
		}
	}
}
