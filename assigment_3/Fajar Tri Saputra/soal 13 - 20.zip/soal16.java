package com.xsis.soal;

public class soal16 {
	
public static void main (String args[]) {
		
		int n = 9;
	
		for (int a=1;a<=n;a++)
		{
			for (int b=n;b>a;b--)
			{
				System.out.print(" ");
			}
			for (int c=1;c<=2*a-1;c++)
			{
				System.out.print("*");
			}
			for (int d=n;d>a;d--)
			{
				System.out.print(" ");
			}
		System.out.println();
		}
	}
}
