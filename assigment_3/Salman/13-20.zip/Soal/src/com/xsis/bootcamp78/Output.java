package com.xsis.bootcamp78;

import com.xsis.soal.*;

public class Output {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Soal_20 soal = new Soal_20();
		
		soal.show();
	}

}
