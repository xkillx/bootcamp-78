package com.xsis.soal;

import java.util.Scanner;

public class Soal_18 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int v = -2;
		int imp = 1;
		for (int i=0;i<n;i++) {
			v+=2;
			for (int j=0;j<=0;j++)
				System.out.print("1");
			for (int k=1;k<i;k++)
				System.out.print(v);
			for (int l=imp;l<1;l++)
				System.out.print("1");
			imp = 0;
			System.out.println();
		}
		
		input.close();
	}
}
