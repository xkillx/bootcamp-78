package com.xsis.soal;

import java.util.Scanner;

public class Soal_6 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int nilai = 1;
		int a = 0;
		for (int i=n;i>=1;i--) {
			for (int j=n;j>i;j--)
				System.out.print(" ");
			a++;
			nilai = a;
			for (int k=1;k<i*2;k++)
				System.out.print(nilai++);
			System.out.println();
		}
		
		input.close();
	}
}
