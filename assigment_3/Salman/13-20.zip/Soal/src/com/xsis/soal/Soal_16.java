package com.xsis.soal;

import java.util.Scanner;

public class Soal_16 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		for (int i=0;i<n;i++) {
			for (int j=n-2;j>=i;j--)
				System.out.print(" ");
			for (int k=0;k<=2*i;k++)
				System.out.print("*");
			System.out.println();
		}
		
		input.close();
	}
}
