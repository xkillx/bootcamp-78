package com.xsis.soal;

import java.util.Scanner;

public class Soal_5 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int m = n-1;
		int p = n+m;
		int hit = 1;
		for (int i=0;i<=n;i++) {
			for (int j=p;j>i;j--) {
				System.out.print(hit++);
			}
			p--;
			hit = i+2;
			System.out.println();
		}
		
		input.close();
	}
}
