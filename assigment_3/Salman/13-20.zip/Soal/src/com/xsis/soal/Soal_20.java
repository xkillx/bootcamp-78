package com.xsis.soal;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Soal_20 {
	public void show() {
		try {
			Scanner input = new Scanner(System.in);
			System.out.print("Enter number of column: ");
			int n = input.nextInt();
		
			for (int i=0;i<n;i++) {
				for (int j=n-1;j>i;j--)
					System.out.print(" ");
				for (int k=0;k<=2*i;k++)
					System.out.print("*");
				System.out.println(" ");
			}
			for (int i=n-1;i>0;i--) {
				for (int j=n;j>i;j--)
					System.out.print(" ");
				for (int k=0;k<2*i-1;k++)
					System.out.print("*");
				System.out.println();
			}
		
			input.close();
		}
		catch(InputMismatchException e) {
			System.out.println("Masukan Anda salah");
		}
	}
}
