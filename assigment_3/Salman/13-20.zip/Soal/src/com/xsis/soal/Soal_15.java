package com.xsis.soal;

import java.util.Scanner;

public class Soal_15 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of column: ");
		int n = input.nextInt();
		System.out.print("Enter number of data: ");
		int d = input.nextInt();
		
		int jumData = 0;
		for (int i=0;i<d;i++) {
			if (jumData == n) {
				System.out.println();
				System.out.printf("%9d",i+1);
				jumData = 1;
			}
			else {
				System.out.printf("%9d",i+1);
				jumData++;
			}
		}
		
		input.close();
	}
}
