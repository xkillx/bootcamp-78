package com.xsis.soal;

import java.util.Scanner;

public class Soal_12 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int imp = 1;
		for (int a=0;a<n;a++) {
			for (int b=n;b>a;b--)
				System.out.print("+");
			for (int c=0;c<=0;c++)
				System.out.print("@");
			for (int d=0;d<2*a-1;d++)
				System.out.print("-");
			for (int e=imp;e<=0;e++)
				System.out.print("@");
			imp = 0;
			for (int f=n;f>a;f--)
				System.out.print("+");
			System.out.println();
		}
		
		input.close();
	}
}
