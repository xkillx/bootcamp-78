package com.xsis.soal;

import java.util.Scanner;

public class Soal_17 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		for (int i=0;i<n;i++) {
			for (int j=2*n;j>i;j--) {
				if (j-i<n+1 && j>n)
					System.out.print(" ");
				else
					System.out.print("*");
			}
			System.out.println();
		}
		
		input.close();
	}
}
