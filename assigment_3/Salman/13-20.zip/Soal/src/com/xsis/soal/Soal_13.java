package com.xsis.soal;

import java.util.Scanner;

public class Soal_13 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int v;
		for (int i=0;i<n;i++) {
			v = i+1;
			for (int j=0;j<=i;j++)
				System.out.print(v++);
			v-=2;
			for (int k=1;k<=i;k++)
				System.out.print(v--);
			System.out.println();
		}
		
		input.close();
	}
}
