package com.xsis.soal;

import java.util.Scanner;

public class Soal_9 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int i, j;		
		int v;
		for (i=0;i<n+1;i++) {
			v = (i%2)+1;
			for (j=1;j<=i;j++) {
				v++;
				System.out.print(v%2);
			}
			System.out.println();
		}
		
		input.close();
	}
}
