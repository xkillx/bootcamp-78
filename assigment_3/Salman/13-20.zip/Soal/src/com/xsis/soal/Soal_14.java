package com.xsis.soal;

import java.util.Scanner;

public class Soal_14 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of column: ");
		int n = input.nextInt();
		
		int v = -1;
		for (int i=0;i<n;i++) {
			for (int j=n;j>i;j--)
				System.out.print((v+=2)+" ");
			v = -1;
			System.out.println();
		}
		v = -1;
		for (int i=1;i<n;i++) {
			for (int j=0;j<=i;j++)
				System.out.print((v+=2)+" ");
			v = -1;
			System.out.println();
		}
		
		input.close();
	}
}
