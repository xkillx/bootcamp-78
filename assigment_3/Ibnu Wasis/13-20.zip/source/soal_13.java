package com.xsis.soal;
public class soal_13{
	public static void main(String[] args){
		int n=7,a,c=0;
		for(int i=1;i<=n;i++){
		a=i;
		// for(int j=1;j<=i;j++){
				// System.out.print(a);
				// a++;
				// }
				
		 // a=a-2;
		// for(int x=i;x>1;x--){
			 // System.out.print(a);
			 // a--;
		// }
			for(int j=1;j<=i+c;j++){
				int b=(i+c+1)/2;
				if(j <= b){
					System.out.print(a);
					a++;
					}
				else if(j == b+1){
					a=a-2;
					System.out.print(a);
					a--;
					}
				else{
					System.out.print(a);
					a--;
				}
			}	
			c++;
			System.out.print("\n");
		}
	}
}