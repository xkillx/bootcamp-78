package com.xsis.soal;
public class soal_20{
	public static void main(String[] args){
		int n=5,a=0;
		for(int x=1;x<=n;x++){
			for(int y=n;y>=x;y--){
				System.out.print(" ");
			}
			int z=1;
			while(z <= x+a){
				System.out.print("*");
				z++;
			}
			a++;
			System.out.print("\n");
		}
		a=0;
		for(int x=1;x<=n;x++){
			if(x>1){
				for(int y=1;y<=x;y++){
				System.out.print(" ");
				}
				for(int z=n;z>=x;z--){
				System.out.print("*");
				}
				for(int w=n;w>x;w--){
				System.out.print("*");
				}
				System.out.print("\n");
			}
		}
		
	}
}