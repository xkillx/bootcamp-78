package com.xsis.soal;
public class soal_14{
	public static void main(String[] args){
		int n=9,a;
		for(int i=1;i<=n;i++){
			a=1;
			for(int j=0;j<=n-i;j++){
				System.out.print(" "+a);
				a=a+2;	
			}
		
			System.out.print("\n");
		}
	
		for(int i=1;i<=n;i++){
			a=1;
			if(i>1){
				for(int j=1;j<=i;j++){
				System.out.print(" "+a);
				a=a+2;	
				}
				System.out.print("\n");
			}
	
		}
	}
	
}