package com.xsis.soal;
public class soal_17{
	public static void main(String [] args){
		int n=9;
		for(int i=1;i<=n;i++){
			for(int j=n;j>=i;j--){
				System.out.print("*");
			}
			for(int x=1;x<i;x++){
				System.out.print(" ");
			}
			for(int y=n;y>=i;y--){
				System.out.print("*");
			}
			System.out.print("\n");
		}
	}
}