package com.xsis.soal;
public class soal_19{
	public static void main(String[] args){
		int n=9;
		for(int x=1;x<=n;x++){
			for(int z=n;z>=x;z--){
				System.out.print(" ");
			}
			for(int y=1;y<=x;y++){
				if(y==1 || x==n){
					System.out.print(x);
				}
				else{
					System.out.print(" ");
				}
			}
			for(int i=1;i<=x;i++){
				if(i>1){
					if(i == x || x==n){
					System.out.print(x);
					}
					else{
					System.out.print(" ");
					}
				}
			}
			System.out.print("\n");
		}
	}
}