package com.xsis.soal;
public class soal_18{
	public static void main(String[] args){
		int n=5,a=0;
		for(int x=1;x<=n;x++){
			for(int y=1;y<=x;y++){
				if(y==x || y==1){
					System.out.print("1");
				}
				else{
					System.out.print(a);
				}
			}
			a=a+2;
			System.out.print("\n");
		}
	}
}