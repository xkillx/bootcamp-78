package com.xsis.soal;
import java.util.Scanner;
public class soal_15{
	public static void main(String[] args){
		int n,a=1,b;
		Scanner in = new Scanner(System.in);
		System.out.print("jumlah data :");
		n = in.nextInt();
		System.out.print("Jumlah kolom :");
		b = in.nextInt();
		for(int i=1;i<=3;i++){
			for(int j=1;j<=b;j++){
				if(a<=n){
					System.out.print(" "+a);
					a=a+1;	
				}
			}
			System.out.print("\n");
		}
	
	}
	
}