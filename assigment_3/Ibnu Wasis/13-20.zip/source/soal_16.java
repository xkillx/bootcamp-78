package com.xsis.soal;
public class soal_16{
	public static void main(String [] args){
		int n=9;
		for(int i=1;i<=n;i++){
			for(int x=n;x>=i;x--){
				System.out.print(" ");
			}
			for(int j=1;j<=i;j++){
				System.out.print("*");
			}
			for(int y=1;y<i;y++){
				System.out.print("*");
			}
			System.out.print("\n");
		}
	}
}