package com.xsis.bootcamp78;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import com.xsis.kamus;
import com.xsis.soal.*;
public class hello{
	public static void main(String[] args){
		kamus km = new kamus();
		int hasil = km.getJumlah();
		System.out.print("Soal1:\n");
		soal_1 soal1 = new soal_1();
		soal1.show();
		System.out.print("Soal2:\n");
		soal_2 soal2 = new soal_2();
		soal2.show();
		System.out.print("Soal3:\n");
		soal_3 soal3 = new soal_3();
		soal3.show();
		System.out.print("Soal4:\n");
		soal_4 soal4 = new soal_4();
		soal4.show();
		System.out.print("Soal5:\n");
		soal_5 soal5 = new soal_5();
		soal5.show();
		
		System.out.print("jumlah " + hasil);
		/*JOptionPane.showMessageDialog
		(null,"Hello java alert");*/
	}
}