package com.xsis.bootcamp78;
public class pola5{
	public static void main(String [] args){
	int n=5,a;
	for(int i=1;i<=n;i++){
	a=i;
		for(int j=0;j<=(n*2)-(i*2);j++){
				System.out.print(a);
				a++;
				}
				System.out.print("\n");
	}
	}
}