package com.xsis.bootcamp78;
import com.xsis.kamus;
import com.xsis.soal.*;
public class soal{
	public static void main(String[] args){
		
		soal_1 soal1 = new soal_1();
		soal1.show();
		soal_2 soal2 = new soal_2();
		soal2.show();
		// soal_3 soal3 = new soal_3();
		// soal3.show();
		// soal_4 soal4 = new soal_3();
		// soal4.show();
		// soal_5 soal5 = new soal_3();
		// soal5.show();
		
		
	}
}