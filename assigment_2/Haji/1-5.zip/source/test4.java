package com.xsis.bootcamp78;
import java.util.Scanner;

public class test4{
	public void show(){
		int n;
		int a=1;
		
		System.out.print("Masukkan nilai n: ");
		Scanner in = new Scanner(System.in);
		n = in.nextInt();		
		
		for (int i=1; i<=n;i++){
			for (int j=0; j<i;j++){
				System.out.print(a);
				a=a+1;
			}
			a=1;
			System.out.print("\n");
		}
	}
}