package com.xsis.bootcamp78.soal;
import com.xsis.bootcamp78.*;

public class test{
	public static void main(String args[]){	
			test1  soal1 = new test1();
			soal1.show();
			test2  soal2 = new test2();
			soal2.show();
			test3  soal3 = new test3();
			soal3.show();
			test4  soal4 = new test4();
			soal4.show();
			test5  soal5 = new test5();
			soal5.show();
	}
}