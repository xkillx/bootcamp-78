package com.xsis.bootcamp78;
import javax.swing.JOptionPane; 
import javax.swing.JFrame;
import com.xsis.kamus;

public class hallo{
	public static void main(String args[]){
		//System.out.println("Hello Java");
		
		//alert
		//JOptionPane.showMessageDialog
			//(null,"Hallo java alert");
			
		kamus km = new kamus();
		int hasil = km.getJumlah();
		System.out.println("Jumlah "+ hasil);
	}
}