package com.xsis.soal;

public class Soal_3 {
	public void show() {
		int hit = 0;
		for (int i=0;i<=7;i++) {
			for (int j=0;j<i;j++) {
				System.out.print(hit);
			}
			System.out.println();
			hit++;
		}
	}
}