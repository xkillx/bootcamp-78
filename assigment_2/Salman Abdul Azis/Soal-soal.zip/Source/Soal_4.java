package com.xsis.soal;

public class Soal_4 {
	public void show() {
		int hit = 1;
		for (int i=0;i<=6;i++) {
			for (int j=0;j<i;j++) {
				System.out.print(hit++);
			}
			System.out.println();
			hit = 1;
		}
	}
}