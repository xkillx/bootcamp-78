package com.xsis;

public class Kamus {
	
	public Integer getJumlah() {
		return 4000;
	}
	
}
