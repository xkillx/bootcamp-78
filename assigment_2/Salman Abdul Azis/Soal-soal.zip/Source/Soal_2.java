package com.xsis.soal;

public class Soal_2 {
	public void show() {
		int hit = 1;
		for (int i=0;i<=5;i++) {
			for (int j=0;j<i;j++) {
				System.out.print(hit++);
			}
			System.out.println();
		}
	}
}