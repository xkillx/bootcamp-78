package com.xsis.soal;

public class Soal_5 {
	public void show() {
		int n = 5;
		int m = n-1;
		int p = n+m;
		int hit = 1;
		for (int i=0;i<=n;i++) {
			for (int j=p;j>i;j--) {
				System.out.print(hit++);
			}
			p--;
			hit = i+2;
			System.out.println();
		}
	}
}