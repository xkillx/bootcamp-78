package com.xsis.bootcamp;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
//import com.xsis.kamus;
import com.xsis.bootcamp.soal_1;
import com.xsis.bootcamp.soal_2;
import com.xsis.bootcamp.soal_3;
import com.xsis.bootcamp.soal_4;
import com.xsis.bootcamp.soal_5;

public class Hello{
	public static void main(String[] args){
	/*System.out.print("Hello World");
	kamus km = new kamus();
	int hasil = km.getJumlah();
	System.out.print("\nJumlah "+hasil);
	
	//alert
	JOptionPane.showMessageDialog(null, "Hallo Java Alert");
	*/
	//int x=9;
	//for(int i =1; i<=9; i++){
		//System.out.print(i+" ");
	//}
	//jframe
	
	new soal_1().show();
	System.out.println();
	new soal_2().show();
	System.out.println();
	new soal_3().show();
	System.out.println();
	new soal_4().show();
	System.out.println();
	new soal_5().show();
	
	}
	}
	