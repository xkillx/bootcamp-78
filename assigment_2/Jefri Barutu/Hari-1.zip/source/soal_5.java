package com.xsis.bootcamp;

public class soal_5 {
	public void show(){
	int x=5;
	//int angka=1;
	for(int i=0; i<=x; i++){
		for(int j=1+i; j<=9-i; j++){
		System.out.print(j);
		//angka++;
	}
	System.out.println(" ");
	
	}
	}
	}	