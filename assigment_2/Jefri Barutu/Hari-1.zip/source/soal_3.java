package com.xsis.bootcamp;

public class soal_3{
	public void show(){
	int x=7;

	for(int i=1; i<=x; i++){
		for(int j=1; j<=i; j++){
		System.out.print(i);
	}
	System.out.println(" ");
	}
	}
}