package com.xsis;
public class kamus{
	public Integer getJumlah(){
		return 4000;
		}
		}