package com.xsis.bootcamp;

public class soal_4{
	public void show(){
	int x=6;
	int angka=1;
	for(int i=1; i<=x; i++){
		for(int j=1; j<=i; j++){
		System.out.print(angka);
		angka++;
	}
	System.out.println(" ");
	angka=1;
	}
	}
	}	