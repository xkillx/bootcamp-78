package com.xsis.bootcamp78;

public class Main {
    public static void main(String[] args) {
        new Latihan1().show();
        System.out.println();
        new Latihan2().show();
        System.out.println();
        new Latihan3().show();
        System.out.println();
        new Testing().show();
        System.out.println();
        new Latihan4().show();
        System.out.println();
        new Latihan5().show();
    }
}