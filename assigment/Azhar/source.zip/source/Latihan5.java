package com.xsis.bootcamp78;

public class Latihan5 {
    public void show() {
        int n = 9;
        int angka;
    
        for (int i = n; i >= 1; i--) {
        
            if (i % 2 == 0) {
                angka = 3;
            }
            else {
                angka = 2;
            }
        
            for (int j = 1; j <= i; j++) {
            
                if (j == 1) {
                    System.out.print(1 + " ");
                }
                else {
                    System.out.print(angka * angka + " ");
                    angka += 2;
                }
            }
            
            System.out.println();
        }
    }
}