package com.xsis.bootcamp78;

public class Latihan6 {
    public void show() {
        int n = 9;
		int angka = 1;
		
		for (int i = 1; i <= n; i++) {
			for (int j = n; j >= i; j--) {
				System.out.print("+");
			}
			
			for (int j = 1; j <= angka; j++) {
				if (j == 1 || j == angka) {
					System.out.print("@");
				}
				else {
					System.out.print("-");
				}
			}
			
			angka += 2;
			
			for (int j = n; j >= i; j--) {
				System.out.print("+");
			}
			
			System.out.println();
		}
    }
}
