package com.xsis.bootcamp78;

public class Latihan1 {
    public void show() {
        int n = 7;
        int i, j, k;
    
        for (i = 1; i <= n; i++) {
        
            for (j = 1; j <= i; j++) {
                System.out.print(j);
            }
            
            for (k = j; k <= n; k++) {
                System.out.print("*");
            }
            
            System.out.println();
        }
    }
}