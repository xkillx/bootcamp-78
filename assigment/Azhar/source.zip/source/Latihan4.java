package com.xsis.bootcamp78;

public class Latihan4 {
    public void show() {
        int n = 9;
        int angka;
    
        for (int i = 1; i <= n; i++) {
        
            for (int j = 1; j <= n - i; j++) {
                System.out.print(" ");
            }
        
            for (int j = i; j >= 1; j--) {
            
                System.out.print(j);
                
            }
            
            System.out.println();
        }
    }
}