package com.xsis.bootcamp78;

public class Latihan2 {
    public void show() {
        int n = 5;
    
        for (int i = 1; i <= n; i++) {
            
            for (int j = 1; j <= 6; j++) {
                if (j == i) {
                    System.out.print("1");
                }
                else {
                    System.out.print("0");
                }
            }
            
            System.out.println();
        }
    }
}