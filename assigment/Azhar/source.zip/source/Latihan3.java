package com.xsis.bootcamp78;

public class Latihan3 {
    public void show() {
        int n = 8;
        int angka;
    
        for (int i = 1; i <= n; i++) {
        
            if (i % 2 == 0) {
                angka = 0;
            }
            else {
                angka = 1;
            }
        
            for (int j = 1; j <= i; j++) {
            
                System.out.print(angka);
                
                if (angka == 1) {
                    angka = 0;
                }
                else {
                    angka = 1;
                }
                
            }
            
            System.out.println();
        }
    }
}