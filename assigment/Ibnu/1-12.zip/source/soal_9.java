package com.xsis.soal;
import java.util.Scanner;
public class soal_9{
	public void show(){
	int n;
	Scanner input = new Scanner(System.in);
	System.out.print("Masukan jumlah deret :");
	n= input.nextInt();
	for(int i=1;i<=n;i++){
		//a=i;
		for(int j=0;j<i;j++){
			System.out.print((i+j)%2);
				 //a++;
				}
		
				System.out.print("\n");
	}
	}
}