package com.xsis.soal;
import java.util.Scanner;
public class soal_7{
	public void show(){
	int n;
	Scanner input = new Scanner(System.in);
	System.out.print("Masukan jumlah deret :");
	n= input.nextInt();
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
				
				System.out.print(j);
				}
		for(int x=1;x<=n-i;x++){
				System.out.print("*");
		}
		
				System.out.print("\n");
	}
	}
}