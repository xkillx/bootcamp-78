package com.xsis.soal;
public class soal_12{
	public void show(){
	int n=9;
	for(int i=n;i>=1;i--){
		for(int j=i;j>=1;j--){
			System.out.print("+");
			}
		System.out.print("@");
		for(int j=1;j<=n-i;j++){
			System.out.print("-");
			}
		for(int j=1;j<=n-(i+1);j++){
			System.out.print("-");
			}
		if(i<n){
		System.out.print("@");}
		for(int j=i;j>=1;j--){
			 System.out.print("+");
			 }
		System.out.print("\n");
		}
	}
}