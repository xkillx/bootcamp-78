package com.xsis.soal;
import java.util.Scanner;
public class soal_11{
	public void show(){
	int n,a,b;
	Scanner input = new Scanner(System.in);
	System.out.print("Masukan jumlah deret :");
	n= input.nextInt();
	for(int i=1;i<=n;i++){
		a=2;
		b=3;
		System.out.print("1 ");
		for(int j=i;j<n;j++){
			if(i%2 == 0){
				System.out.print(b*b);
				b=b+2;
				}
			else { 
				System.out.print(a*a);
				a=a+2;
				}
			System.out.print(" ");
			}
		
				System.out.print("\n");
		}
	}
}