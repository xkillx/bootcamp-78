package com.xsis.soal;
import java.util.Scanner;
public class soal_6{
	public void show(){
	int n,a;
	Scanner input = new Scanner(System.in);
	System.out.print("Masukan jumlah deret :");
	n= input.nextInt();
	for(int i=1;i<=n;i++){
	a=i;
		for(int x=n-1;x>=n-i;x--){
				System.out.print(" ");
		}
		for(int j=0;j<=(n*2)-(i*2);j++){
				
				System.out.print(a);
				a++;
				}
		
				System.out.print("\n");
	}
	}
}