package com.xsis.soal;
import java.util.Scanner;
public class soal_10{
	public void show(){
	int n,a;
	Scanner input = new Scanner(System.in);
	System.out.print("Masukan jumlah deret :");
	n= input.nextInt();
	for(int i=1;i<=n;i++){
	a=i;
		for(int x=n-1;x>=i;x--){
		System.out.print(" ");
		}
		for(int j=1;j<=i;j++){
		System.out.print(a);
		a--;
				}
		
				System.out.print("\n");
	}
	}
}