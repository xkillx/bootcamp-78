package com.xsis.soal;
public class soal_5{
	public void show(){
	int n=9,a;
	for(int i=1;i<=n;i++){
	a=i;
		for(int j=0;j<=(n*2)-(i*2);j++){
				System.out.print(a);
				a++;
				}
				System.out.print("\n");
	}
	}
}