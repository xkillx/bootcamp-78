package com.xsis.bootcamp78;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import com.xsis.kamus;
import com.xsis.soal.*;
public class hello{
	public static void main(String[] args){
		kamus km = new kamus();
		int hasil = km.getJumlah();
		System.out.print("jumlah " + hasil);
		System.out.print("\nSoal 1:\n\n");
		soal_1 soal1 = new soal_1();
		soal1.show();
		System.out.print("\nSoal 2:\n\n");
		soal_2 soal2 = new soal_2();
		soal2.show();
		System.out.print("\nSoal 3:\n\n");
		soal_3 soal3 = new soal_3();
		soal3.show();
		System.out.print("\nSoal 4:\n\n");
		soal_4 soal4 = new soal_4();
		soal4.show();
		System.out.print("\nSoal 5:\n\n");
		soal_5 soal5 = new soal_5();
		soal5.show();
		System.out.print("\nSoal 6:\n\n");
		soal_6 soal6 = new soal_6();
		soal6.show();
		System.out.print("\nSoal 7:\n\n");
		soal_7 soal7 = new soal_7();
		soal7.show();
		System.out.print("\nSoal 8:\n\n");
		soal_8 soal8 = new soal_8();
		soal8.show();
		System.out.print("\nSoal 9:\n\n");
		soal_9 soal9 = new soal_9();
		soal9.show();
		System.out.print("\nSoal 10:\n\n");
		soal_10 soal10 = new soal_10();
		soal10.show();
		System.out.print("\nSoal 11:\n\n");
		soal_11 soal11 = new soal_11();
		soal11.show();
		System.out.print("\nSoal 12:\n\n");
		soal_12 soal12 = new soal_12();
		soal12.show();
		
		
		/*JOptionPane.showMessageDialog
		(null,"Hello java alert");*/
	}
}