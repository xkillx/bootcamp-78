package com.xsis.soal;
import java.util.Scanner;
public class soal_8{
	public void show(){
	int n,c;
	Scanner input = new Scanner(System.in);
	System.out.print("Masukan jumlah deret :");
	n= input.nextInt();
	System.out.print("Masukan jumlah kolom :");
	c= input.nextInt();
	for(int i=1;i<=n;i++){
		for(int j=1;j<=c;j++){
				if(i==j){
					System.out.print("1");
				}else{
					System.out.print("0");
				}
				
				
				}
		
				System.out.print("\n");
	}
	}
}