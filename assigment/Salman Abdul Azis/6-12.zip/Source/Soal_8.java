package com.xsis.soal;

import java.util.Scanner;

public class Soal_8 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		System.out.print("Enter number 1 frequency: ");
		int c = input.nextInt();
		
		int i, j;
		for (i=0;i<n;i++) {
			for (j=0;j<6;j++) {
				if (i==j && j<c)
					System.out.print("1");
				else
					System.out.print("0");
			}
			System.out.println();
		}
	}
}