package com.xsis.bootcamp78;

import javax.swing.JOptionPane;
import javax.swing.JFrame;
import com.xsis.Kamus;

import com.xsis.soal.*;

public class HelloWorld {
	public static void main(String[] args) {

		Soal_1 s1 = new Soal_1();
		Soal_2 s2 = new Soal_2();
		Soal_3 s3 = new Soal_3();
		Soal_4 s4 = new Soal_4();
		Soal_5 s5 = new Soal_5();
		Soal_6 s6 = new Soal_6();
		Soal_7 s7 = new Soal_7();
		Soal_8 s8 = new Soal_8();
		Soal_9 s9 = new Soal_9();
		Soal_10 s10 = new Soal_10();
		Soal_11 s11 = new Soal_11();
		Soal_12 s12 = new Soal_12();
		
		/*
		s1.show();
		s2.show();
		s3.show();
		s4.show();
		
		System.out.println();
		
		s5.show();
		s6.show();
		
		System.out.println();
		
		s7.show();
		
		System.out.println();
		
		s8.show();
		
		System.out.println();
		
		s9.show();
		
		System.out.println();
		
		s10.show();
		
		System.out.println();
		
		s11.show();*/
		s12.show();
		
		/*
		int hit = 1;
		for (int i=0;i<=5;i++) {
			for (int j=0;j<i;j++) {
				System.out.print(hit++);
			}
			System.out.println();
		}
		*/
		
		/*
		for (int i=0;i<=5;i++) {
			for (int j=0;j<i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		*/
		
		/*
		int j;
		for (int i=0;i<10;i++) {
			j = i+1;
			System.out.print(" "+j);
		}
		*/
			
		/*
		Kamus km = new Kamus();
		int hasil = km.getJumlah();
		
		System.out.println("Jumlah "+hasil);
		
		//alert
		JOptionPane.showMessageDialog (null,"Hello Java Alert");
		
		//System.out.println("city"+arg[0]);
		//System.out.println("jalan"+arg[1]);
		
		//jframe
		*/
	}
}