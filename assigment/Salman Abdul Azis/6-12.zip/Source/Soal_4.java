package com.xsis.soal;

import java.util.Scanner;

public class Soal_4 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int hit = 1;
		for (int i=0;i<=n;i++) {
			for (int j=0;j<i;j++) {
				System.out.print(hit++);
			}
			System.out.println();
			hit = 1;
		}
	}
}