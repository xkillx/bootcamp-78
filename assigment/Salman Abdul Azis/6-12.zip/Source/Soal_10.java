package com.xsis.soal;

import java.util.Scanner;

public class Soal_10 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int i,j,k,v;
		for (i=0;i<n;i++) {
			v = n-(n-i-1);
			for (j=n;j>i+1;j--)
				System.out.print(" ");
			for (k=0;k<=i;k++)
				System.out.print(v--);
			System.out.println();
		}
	}
}