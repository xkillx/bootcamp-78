package com.xsis.soal;

import java.util.Scanner;

public class Soal_7 {
	public void show() {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int n = input.nextInt();
		
		int i, j, k;
		for (i=0;i<n;i++) {
			for (j=0;j<=i;j++)
				System.out.print(j+1);
			for (k=n;k>j;k--)
				System.out.print("*");
			System.out.println();
		}
	}
}