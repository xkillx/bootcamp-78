package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal8{
	public static void main(String args[]){	
		int n;
		int c;
		
		Scanner in = new Scanner(System.in);

		System.out.print("Masukkan nilai n: ");
		n = in.nextInt();		
		
		System.out.print("Masukkan nilai c: ");
		c = in.nextInt();		

		for(int i=1;i<=n;i++){
			for(int j=0;j<c;j++){
				if(j+1==i) System.out.print("1");
				else System.out.print("0");
			}
			System.out.println();
		}
	}
}