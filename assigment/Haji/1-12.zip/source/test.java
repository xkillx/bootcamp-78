package com.xsis.bootcamp78;

public class test{
	public static void main(String args[]){	
			soal1  soal1 = new soal1();
			soal1.show();
			soal2  soal2 = new soal2();
			soal2.show();
			soal3  soal3 = new soal3();
			soal3.show();
			soal4  soal4 = new soal4();
			soal4.show();
			soal5  soal5 = new soal5();
			soal5.show();
	}
}