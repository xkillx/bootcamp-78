package com.xsis.bootcamp78;
import java.util.Scanner;

public class soal11{
	public static void main(String args[]){	
		int n;
		int k;
		
		System.out.print("Masukkan nilai n: ");
		Scanner in = new Scanner(System.in);
		n = in.nextInt();		
		
		for (int i=n;i>0;i--){
			k=(i+1)%2;
			System.out.print("1 ");
			for (int j=1;j<i;j++){
				k+=2;
				System.out.print(pangkat(k)+" ");
			}
			System.out.println();
		}
	}
	
	public static int pangkat(int p){
		int hasil= p*p;
		return hasil;
	}

}