package com.xsis.soal;

public class soal12 {

	public static void main (String args[]) {
	
		int n = 9;	
		
		for ( int i=1; i<=n;i++ ){
			for ( int j=i;j>=1;j--){
				System.out.print(j);
			}
			for ( int l=i;l<=n;l++){
				System.out.print(l);
			}
			System.out.println();
		}
	}}
		
		/*int n = 9;
		int imp = 2;
		
		for (int a=0;a<n;a++){ // buat baris
			for (int b=n;b>a;b--)
				System.out.print("+");
			for (int c=1;c<=1;c++)
				System.out.print("@");
			for (int d=0;d<2*a-1;d++)
				System.out.print("-");
			for (int e=imp;e<=1;e++)
				System.out.print("@");
				imp = 1;
			for (int f=n;f>a;f--)
				System.out.print("+");
			System.out.println();
			}*/
		
