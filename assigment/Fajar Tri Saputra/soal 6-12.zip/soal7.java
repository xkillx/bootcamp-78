package com.xsis.soal;
import com.xsis.*;
 
public class soal7 {

	public static void main (String args[]) {
	
	int n = 7;
		
		for ( int a=1;a<=n;a++)	
		{
			for (int b=1;b<=n;b++)
			{
			if (b>a)
				{
				System.out.print("*");
				}
			else
				{
				System.out.print(b);
				}
		}
		System.out.println("");
	}
}}