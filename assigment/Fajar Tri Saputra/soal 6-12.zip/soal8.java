package com.xsis.soal;
import com.xsis.*; 
import java.util.Scanner;

public class soal8 {

	public static void main (String args[]) {
	
	Scanner in = new Scanner(System.in);
		
		int n,c;
		
	System.out.print("masukan nilai 'n' : ");
		n = in.nextInt();
		
	System.out.print("masukan nilai 'c' : ");
		c = in.nextInt();
		
		for ( int a=1;a<=n;a++)	
		{
			for (int b=1;b<=c;b++)
			{
			if (b==a)
				{
				System.out.print("1");
				}
			else
				{
				System.out.print("0");
				}
		}
		System.out.println("");
	}
}}