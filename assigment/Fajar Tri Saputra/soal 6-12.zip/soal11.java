package com.xsis.soal;
import com.xsis.*;
 
public class soal11 {

	public static void main (String args[]) {
	
	int n = 9;
	int y = 2; //variabel untuk pola angka pertama
	int x = 3; //variabel untuk pola angka kedua
	
	for (int i=n;i>=1;i--) // for untuk baris
	{
	System.out.print("1"+" ");

	if ( i % 2 == 1) //jika i ganjil
	{
		for (int j=1;j<n;j++)
		{
			System.out.print(y*y+" ");//pola angka baris pertama
			y+=2;
		}
		n-=2;
		System.out.println();
	y = 2;
	}
	else 
	{
		for ( int k=1;k<=n;k++)
		{
			System.out.print(x*x+" "); //pola angka baris kedua
			x+=2;
		}
		System.out.println();
	x = 3;
	}
}}}	