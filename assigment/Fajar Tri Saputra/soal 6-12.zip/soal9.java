package com.xsis.soal;
import com.xsis.*;
 
public class soal9 {

	public static void main (String args[]) {
	
	int n = 8;
			
		for ( int a=1;a<=n;a++)	
		{
			for (int b=1;b<a;b++)
			{
				int c = (a+b)%2;
				System.out.print(c);
				
			}
		System.out.println();
		}
		
		/*for ( int a=1;a<=n;a++)
		{
			for (int b=a;b>=1;b--)
			{
				System.out.print(b%2);
			}
		System.out.println();
		}*/
	}
}