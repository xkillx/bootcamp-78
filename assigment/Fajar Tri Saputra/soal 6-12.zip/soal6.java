package com.xsis.soal; //SOAL 5
import com.xsis.*; //bintang untuk load semua package

public class soal6 {

	public static void main (String args[]) {
	
		int n = 5;
		int x = 1;
		
        for ( int i = (n-1)+n; i > 1; i--) 
		{
		System.out.print(" ");
            for ( int j = x; j <= i; j++) 
			{
                System.out.print(j);
            }
        System.out.println("");
		x++;
        }
	}
}