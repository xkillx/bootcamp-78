package com.xsis.soal; //SOAL 5
import com.xsis.*; //bintang untuk load semua package

public class soal6kedua {

	public static void main (String args[]) {
	
		int n = 5;
		
		for (int a=1;a<=n;a++)
		{
			for (int b=1;b<a;b++)
			{
				System.out.print(" ");
			}
	
			for (int c=0+a;c < n*2-1;c++)
			{ 
				System.out.print(c+" ");
			}
			System.out.println("");
		}
	}
}