package com.xsis.bootcamp;
import java.util.Scanner;

public class soal_9 {
	//public void show(){
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.print("Input n = ");
		int n = scan.nextInt();
		

	for(int i=1; i<=n; i++){
		for(int j=i; j>=1; j--){
		System.out.print(j%2);
	/*
	for(int i=0; i<=n; i++){
		for(int j=n; j<i; j++){
	int c = (i+j)%2;
			System.out.print(c);
	*/
	}	
	System.out.println(" ");
	}
	}
	}
	//}