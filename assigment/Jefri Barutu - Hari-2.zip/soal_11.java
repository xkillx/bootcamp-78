package com.xsis.bootcamp;
import java.util.Scanner;

public class soal_11 {
	//public void show(){
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.print("Input n = ");
		int n = scan.nextInt();
		
	
	//int b;
	
	int x = 3;
	
	for (int i=n;i>=1;i--)
	{
	System.out.print("1"+" ");

	if ( i % 2 == 1)
	{
		for (int j=1;j<n;j++)
		{
			System.out.print(j*j*4+" "); //untuk baris 1
		}
		n-=2; //batas kolom kurang
		System.out.println();
	}
	else
	{
		for ( int k=1;k<=n;k++)
		{
			System.out.print(x*x+" "); //untuk baris 2
			x+=2;
		}
		System.out.println();
	x = 3;
	}
	}
	}
	}