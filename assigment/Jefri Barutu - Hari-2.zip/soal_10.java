package com.xsis.bootcamp;
import java.util.Scanner;

public class soal_10 {
	//public void show(){
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.print("Input n = ");
		int n = scan.nextInt();
		

	for(int i=1; i<=n; i++){
		for(int j=n; j>=i; j--){
		System.out.print(" ");
	}
	for(int a=i; a>=1; a--){
	System.out.print(a);
	
	}
		System.out.println(" ");
			
	}
	
	}
	}