package com.xsis.bootcamp;
import java.util.Scanner;

public class soal_7 {
	//public void show(){
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.print("Input n = ");
		int n = scan.nextInt();
		
	int angka =1;
	for(int i=1; i<=n; i++){
		for(int j=1; j<=n; j++){
		if(j>i){
		System.out.print("*");
		}else{
		System.out.print(j);
//		System.out.print(angka);
//		angka++;
//		for(int a=1; a<=n; a++){
//		System.out.print("*");
		
	//	}
	}
	
	}System.out.println(" ");
	}
	}
	}