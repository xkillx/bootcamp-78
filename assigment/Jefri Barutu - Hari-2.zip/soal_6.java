package com.xsis.bootcamp;
import java.util.Scanner;

public class soal_6 {
	//public void show(){
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.print("Input n = ");
		int n = scan.nextInt();
		

	for(int i=1; i<=n; i++){
		for(int j=1; j<i; j++){
		System.out.print(" ");
		//angka++;
	}
	for(int a=0+i; a<=n*2-i; a++){
		
	System.out.print(a);
	
	//}
	}
	System.out.println(" ");
	}
	}
	}