package com.xsis.bootcamp;
import java.util.Scanner;

public class soal_8 {
	//public void show(){
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.print("Input n = ");
		int n = scan.nextInt();
		System.out.print("Input c = ");
		int c = scan.nextInt();

	
	
	for(int i=1; i<=n; i++){
		for(int j=1; j<=n; j++){
		if(i==j){
		System.out.print("1");
		//if(i==2){
			//System.out.print("");
			//i+=2;
	}else{
		System.out.print("0");
	
	}
	
	}System.out.println(" ");
	}
	}
	}