package com.xsis.bootcamp;
import java.util.*;
public class soal_12 {
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		System.out.print("Input n = ");
		int n = scan.nextInt();
		
		int p= 2;
		for(int y=0; y<n; y++){
			
			for(int i=n; i>y; i--)
				System.out.print("+");
		
			for(int j=1; j<=1; j++)
				System.out.print("@");
			
			for(int a=0; a<2*y-1; a++)
				System.out.print("-");
			
			for(int b=p; b<=1; b++)
				System.out.print("@");
			
			p=1;
			
			for(int c=n; c>y; c--)
				System.out.print("+");
			System.out.println();
		
		}
		
	}

}